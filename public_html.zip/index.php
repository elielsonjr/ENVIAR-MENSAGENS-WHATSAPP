<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>PostManager — Dashboard</title>
  <link rel="stylesheet" href="assets/css/main.css" />
  <link rel="stylesheet" href="assets/css/dashboard.css" />
</head>
<body class="dashboard-layout">

<header class="topbar">
  <div class="topbar-brand">
    <div class="topbar-logo">📅</div>
    <div><span class="topbar-name">PostManager</span><span class="topbar-sub">Controle de Conteúdo</span></div>
  </div>
  <div class="topbar-right">
    <button class="btn btn-primary" id="btnNewClient">+ Novo Cliente</button>
  </div>
</header>

<div class="dashboard-body">
  <div class="page-header">
    <div><h1 class="page-title">Dashboard</h1><p class="page-subtitle" id="weekLabel"></p></div>
  </div>
  <div class="dashboard-content">
    <div class="client-grid" id="clientGrid"></div>
    <aside class="holiday-widget" id="holidayWidget"></aside>
  </div>
</div>

<!-- Modal: Novo/Editar Cliente -->
<div class="modal-overlay" id="modalClient">
  <div class="modal">
    <div class="modal-header">
      <h3 class="modal-title" id="clientModalTitle">Novo Cliente</h3>
      <button class="modal-close" id="btnCloseClientModal">✕</button>
    </div>
    <div class="modal-body">
      <!-- Photo upload -->
      <div class="form-group">
        <label class="form-label">Foto do Perfil</label>
        <div class="photo-upload-row">
          <div class="photo-upload-ring" id="photoRing" title="Clique para adicionar foto">
            <img id="photoPreviewImg" style="display:none"/>
            <div class="pur-hint" id="purHint"><span>📷</span>Adicionar foto</div>
          </div>
          <div class="photo-actions">
            <button class="btn btn-secondary btn-sm" id="btnPickPhoto" type="button">Carregar imagem</button>
            <button class="btn btn-sm" id="btnRemovePhoto" type="button" style="background:none;border:1px solid var(--border);color:var(--text-3)">Remover foto</button>
          </div>
        </div>
        <input type="file" id="photoInput" accept="image/*" style="display:none"/>
      </div>
      <!-- Name -->
      <div class="form-group">
        <label class="form-label">Nome da Empresa</label>
        <input class="input" id="clientNameInput" placeholder="Ex: Padaria Bella Vista"/>
      </div>
      <!-- Instagram -->
      <div class="form-group">
        <label class="form-label">Instagram <span style="color:var(--text-3);font-weight:400">(opcional — clique no nome para abrir)</span></label>
        <div class="input-ig">
          <span class="input-ig-prefix">@</span>
          <input class="input" id="igInput" placeholder="usuario_instagram"/>
        </div>
      </div>
      <!-- Sync URL -->
      <div class="form-group">
        <label class="form-label">URL de Sincronização (IDIB / IDECAN)</label>
        <input class="input" id="clientSyncUrlInput" placeholder="Ex: https://concurso.idib.org.br/ ou https://concurso.idecan.org.br/"/>
      </div>
      <!-- Color -->
      <div class="form-group">
        <label class="form-label">Cor de Identificação</label>
        <div class="color-picker" id="colorPicker">
          <div class="color-swatch active" data-color="#6366f1" style="background:#6366f1"></div>
          <div class="color-swatch" data-color="#ec4899" style="background:#ec4899"></div>
          <div class="color-swatch" data-color="#f59e0b" style="background:#f59e0b"></div>
          <div class="color-swatch" data-color="#10b981" style="background:#10b981"></div>
          <div class="color-swatch" data-color="#3b82f6" style="background:#3b82f6"></div>
          <div class="color-swatch" data-color="#8b5cf6" style="background:#8b5cf6"></div>
          <div class="color-swatch" data-color="#ef4444" style="background:#ef4444"></div>
          <div class="color-swatch" data-color="#14b8a6" style="background:#14b8a6"></div>
          <div class="color-swatch" data-color="#f97316" style="background:#f97316"></div>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" id="btnCancelClient">Cancelar</button>
      <button class="btn btn-primary" id="btnSaveClient">Salvar</button>
    </div>
  </div>
</div>

<!-- Modal: Marcar Dia -->
<div class="modal-overlay" id="modalMark">
  <div class="modal">
    <div class="modal-header">
      <div>
        <h3 class="modal-title" id="markTitle">Marcar Dia</h3>
        <p class="modal-subtitle" id="markSub"></p>
      </div>
      <button class="modal-close" id="btnCloseMark">✕</button>
    </div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">O que foi / será postado?</label>
        <input class="input" id="markPostTitle" placeholder="Ex: Post Instagram, Reels, Stories…" />
      </div>
      <div id="existingPostsArea"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" id="btnCancelMark">Cancelar</button>
      <button class="btn btn-primary" id="btnSaveMark">Marcar</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>
<script src="assets/js/dashboard.js"></script>
</body>
</html>
