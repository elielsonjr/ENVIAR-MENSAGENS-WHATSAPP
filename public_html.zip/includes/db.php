<?php
require_once __DIR__ . '/../config.php';

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST, DB_NAME, DB_CHARSET
        );
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);

        // Auto-initialize database tables if 'clients' table does not exist
        try {
            $pdo->query("SELECT 1 FROM clients LIMIT 1");
        } catch (PDOException $e) {
            if ($e->getCode() === '42S02' || strpos($e->getMessage(), '1146') !== false) {
                $sqlFile = __DIR__ . '/../install.sql';
                if (file_exists($sqlFile)) {
                    $sql = file_get_contents($sqlFile);
                    if ($sql) {
                        try {
                            $pdo->exec($sql);
                        } catch (PDOException $ex) {
                            // If multi-query fails, try splitting by semicolon
                            $queries = explode(';', $sql);
                            foreach ($queries as $query) {
                                $query = trim($query);
                                if ($query !== '') {
                                    try {
                                        $pdo->exec($query);
                                    } catch (PDOException $ex2) {
                                        // Ignore errors on individual queries
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        try {
            $pdo->query("SELECT sync_url FROM clients LIMIT 1");
        } catch (PDOException $e) {
            try {
                $pdo->exec("ALTER TABLE clients ADD COLUMN sync_url VARCHAR(255) DEFAULT NULL");
            } catch (PDOException $ex) {
                // Silently ignore if table does not exist yet (e.g. during fresh install)
            }
        }
        try {
            $pdo->query("SELECT instagram FROM clients LIMIT 1");
        } catch (PDOException $e) {
            try {
                $pdo->exec("ALTER TABLE clients ADD COLUMN instagram VARCHAR(100) DEFAULT NULL");
            } catch (PDOException $ex) {}
        }
        try {
            $pdo->query("SELECT photo FROM clients LIMIT 1");
        } catch (PDOException $e) {
            try {
                $pdo->exec("ALTER TABLE clients ADD COLUMN photo LONGTEXT DEFAULT NULL");
            } catch (PDOException $ex) {}
        }
    }
    return $pdo;
}

