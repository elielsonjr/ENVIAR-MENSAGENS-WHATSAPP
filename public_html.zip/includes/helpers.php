<?php
// ─── Feriados Nacionais Brasileiros ────────────────

function getEasterDate(int $year): DateTime {
    $a = $year % 19;
    $b = intdiv($year, 100);
    $c = $year % 100;
    $d = intdiv($b, 4);
    $e = $b % 4;
    $f = intdiv($b + 8, 25);
    $g = intdiv($b - $f + 1, 3);
    $h = (19 * $a + $b - $d - $g + 15) % 30;
    $i = intdiv($c, 4);
    $k = $c % 4;
    $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
    $m = intdiv($a + 11 * $h + 22 * $l, 451);
    $month = intdiv($h + $l - 7 * $m + 114, 31);
    $day   = ($h + $l - 7 * $m + 114) % 31 + 1;
    return new DateTime(sprintf('%04d-%02d-%02d', $year, $month, $day));
}

function getNationalHolidays(int $year): array {
    $fixed = [
        '01-01' => 'Confraternização Universal',
        '04-21' => 'Tiradentes',
        '05-01' => 'Dia do Trabalho',
        '09-07' => 'Independência do Brasil',
        '10-12' => 'Nossa Sra. Aparecida',
        '11-02' => 'Finados',
        '11-15' => 'Proclamação da República',
        '11-20' => 'Consciência Negra',
        '12-25' => 'Natal',
    ];

    $result = [];
    foreach ($fixed as $md => $name) {
        $result["$year-$md"] = $name;
    }

    $easter  = getEasterDate($year);
    $movable = [
        -48 => 'Carnaval (Domingo)',
        -47 => 'Carnaval (Segunda-feira)',
        -2  => 'Sexta-feira Santa',
         0  => 'Páscoa',
        60  => 'Corpus Christi',
    ];
    foreach ($movable as $offset => $name) {
        $d = clone $easter;
        $d->modify("$offset days");
        $result[$d->format('Y-m-d')] = $name;
    }

    ksort($result);
    return $result;
}

// ─── Utilitários HTTP ──────────────────────────────

function jsonResponse(mixed $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', false);
    header('Pragma: no-cache');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function getRequestBody(): array {
    $body = file_get_contents('php://input');
    return json_decode($body ?: '{}', true) ?? [];
}

function sanitize(string $str): string {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}
