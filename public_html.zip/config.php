<?php
// ═══════════════════════════════════════════════════
//  PostManager — Configuração do Banco de Dados
//  Preencha com suas credenciais do Hostinger
// ═══════════════════════════════════════════════════

define('DB_HOST',    'localhost');          // Geralmente 'localhost' no Hostinger
define('DB_NAME',    'u738303317_empresas');     // Nome do banco criado no hPanel
define('DB_USER',    'u738303317_empresas');   // Usuário do banco
define('DB_PASS',    'BYSERGGIO123s');     // Senha do banco
define('DB_CHARSET', 'utf8mb4');

// URL base da aplicação (sem barra no final)
// Ex: 'https://seudominio.com.br' ou '' para raiz
define('BASE_URL', '');
