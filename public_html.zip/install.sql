-- ═══════════════════════════════════════════════════
--  PostManager — Script de Instalação do Banco
--  Execute este arquivo no phpMyAdmin do Hostinger
-- ═══════════════════════════════════════════════════

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ── Clientes ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS `clients` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) NOT NULL,
  `color`      VARCHAR(7)   NOT NULL DEFAULT '#6366f1',
  `sync_url`   VARCHAR(255) DEFAULT NULL,
  `instagram`  VARCHAR(100) DEFAULT NULL,
  `photo`      LONGTEXT     DEFAULT NULL,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Postagens ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS `posts` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id`  INT UNSIGNED NOT NULL,
  `date`       DATE         NOT NULL,
  `title`      VARCHAR(255) NOT NULL DEFAULT '',
  `status`     ENUM('planned','scheduled','published') NOT NULL DEFAULT 'planned',
  `sort_order` SMALLINT     NOT NULL DEFAULT 0,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_client_date` (`client_id`, `date`),
  CONSTRAINT `fk_posts_client`
    FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Notas por Dia ─────────────────────────────────
CREATE TABLE IF NOT EXISTS `notes` (
  `id`        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `date`      DATE         NOT NULL,
  `content`   TEXT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_client_date` (`client_id`, `date`),
  CONSTRAINT `fk_notes_client`
    FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Feriados Personalizados ───────────────────────
-- (Feriados nacionais são calculados automaticamente em PHP)
CREATE TABLE IF NOT EXISTS `holidays` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `date`        DATE         NOT NULL,
  `name`        VARCHAR(100) NOT NULL,
  `is_national` TINYINT(1)   NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
