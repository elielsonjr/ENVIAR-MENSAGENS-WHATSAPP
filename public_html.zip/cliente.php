<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Calendário — PostManager</title>
  <link rel="stylesheet" href="assets/css/main.css"/>
  <link rel="stylesheet" href="assets/css/client.css"/>
</head>
<body class="client-layout">

<header class="client-topbar">
  <div class="client-topbar-left">
    <button class="back-btn" onclick="location.href='index.php'">← Dashboard</button>
    <div class="client-topbar-name-wrap">
      <div class="client-topbar-dot" id="clientDot"></div>
      <span class="client-topbar-name" id="clientName">…</span>
    </div>
  </div>
  <div class="client-topbar-right">
    <button class="btn btn-primary btn-sm" id="btnAddToday">+ Post hoje</button>
  </div>
</header>

<div class="client-body">
  <!-- Month nav -->
  <div class="month-nav-bar">
    <div class="month-nav-center">
      <button class="month-nav-btn" id="btnPrevMonth">‹</button>
      <span class="month-title" id="monthTitle">…</span>
      <button class="month-nav-btn" id="btnNextMonth">›</button>
    </div>
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <button class="month-today-btn" id="btnThisMonth">Mês atual</button>
      <div class="month-pills">
        <span class="mpill mpill-published" id="mpPublished">—</span>
      </div>
    </div>
  </div>

  <!-- Calendar grid -->
  <div class="month-grid">
    <div class="month-grid-header">
      <div class="mgh-cell">Dom</div><div class="mgh-cell">Seg</div>
      <div class="mgh-cell">Ter</div><div class="mgh-cell">Qua</div>
      <div class="mgh-cell">Qui</div><div class="mgh-cell">Sex</div>
      <div class="mgh-cell">Sáb</div>
    </div>
    <div class="month-grid-body" id="calBody"></div>
  </div>
</div>

<!-- Day Modal -->
<div class="modal-overlay" id="modalDay">
  <div class="modal modal-day">
    <div class="modal-header">
      <div>
        <h3 class="modal-title day-modal-title" id="dayModalTitle">—</h3>
        <p class="day-modal-sub" id="dayModalSub"></p>
      </div>
      <button class="modal-close" id="btnCloseDay">✕</button>
    </div>
    <div class="modal-body">
      <div id="dayHolidayAlert" class="day-holiday-alert" style="display:none"></div>
      <div class="section-label">Postagens</div>
      <div class="modal-posts-list" id="dayPostsList"></div>
      <button class="modal-add-post" id="btnAddPost">+ Adicionar Postagem</button>
      <div class="divider"></div>
      <div class="section-label">Anotação</div>
      <textarea class="modal-note" id="dayNote" placeholder="Observações, briefing, lembretes…" rows="3"></textarea>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" id="btnCancelDay">Fechar</button>
      <button class="btn btn-primary" id="btnSaveDay">💾 Salvar</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>
<script src="assets/js/client.js"></script>
</body>
</html>
