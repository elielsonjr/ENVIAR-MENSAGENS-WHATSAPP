// ══════════════════════════════════════════
//  dashboard.js — Simplified marking
// ══════════════════════════════════════════

const DS = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const ML = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

let allClients = [], weekPosts = {}, allHolidays = {}, allDeadlines = {};
let miniCalYear, miniCalMonth;
let markClientId = null, markDate = null, markStatus = 'published';
let editingClientId = null, selectedColor = '#6366f1', selectedPhoto = '';

function fmt(d){ const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),dd=String(d.getDate()).padStart(2,'0'); return `${y}-${m}-${dd}`; }
function getWeekBounds(){ const t=new Date(),dow=t.getDay(),s=new Date(t); s.setDate(t.getDate()-dow); const e=new Date(s); e.setDate(s.getDate()+6); return{start:fmt(s),end:fmt(e),startDate:new Date(s)}; }
function api(p,o={}){
  let url = p;
  if (!o.method || o.method.toUpperCase() === 'GET') {
    const separator = p.includes('?') ? '&' : '?';
    url = `${p}${separator}_t=${Date.now()}`;
  }
  return fetch(url,{headers:{'Content-Type':'application/json'},...o})
    .then(async r=>{
      const text = await r.text();
      let json;
      try {
        json = JSON.parse(text);
      } catch (err) {
        throw new Error(text.slice(0, 150) || `Erro HTTP ${r.status}`);
      }
      if (!r.ok || (json && json.error)) {
        throw new Error(json?.error || `Erro HTTP ${r.status}`);
      }
      return json;
    });
}
function toast(m){ const el=document.getElementById('toast'); el.textContent=m; el.classList.add('show'); clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),2500); }
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
function igUrl(s){ if(!s) return ''; if(s.startsWith('http')) return s; return 'https://instagram.com/'+s.replace(/^@/,'').split('/')[0]; }

// ── Load ──────────────────────────────────
async function loadAll(){
  const {start,end} = getWeekBounds();
  const yr = new Date().getFullYear();
  const [clients,posts,hols,deadlines] = await Promise.all([
    api('api/clients.php'),
    api(`api/posts.php?week_start=${start}&week_end=${end}`),
    api(`api/holidays.php?year=${yr}`),
    api('api/posts.php?deadlines=1'),
  ]);
  allClients = clients;
  weekPosts = {};
  posts.forEach(p=>{ if(!weekPosts[p.date]) weekPosts[p.date]=[]; weekPosts[p.date].push(p); });
  allHolidays = {};
  hols.forEach(h=>{ allHolidays[h.date]=h.name; });
  // Also get next year
  api(`api/holidays.php?year=${yr+1}`).then(h2=>h2.forEach(h=>allHolidays[h.date]=h.name));

  allDeadlines = {};
  if (Array.isArray(deadlines)) {
    deadlines.forEach(d=>{
      if(!allDeadlines[d.date]) allDeadlines[d.date]=[];
      allDeadlines[d.date].push(d.title);
    });
  }
  render();
}

// ── Render ────────────────────────────────
function render(){
  renderWeekLabel();
  renderClients();
  renderHolidayWidget();
}

function renderWeekLabel(){
  const {start,end} = getWeekBounds();
  const s=new Date(start+'T12:00:00'), e=new Date(end+'T12:00:00');
  document.getElementById('weekLabel').textContent = `Semana de ${s.getDate()}/${s.getMonth()+1} a ${e.getDate()}/${e.getMonth()+1}/${e.getFullYear()}`;
}

function renderClients(){
  const grid = document.getElementById('clientGrid');
  if(!allClients.length){
    grid.innerHTML=`<div class="empty-state"><div class="empty-icon">👥</div><div class="empty-title">Nenhum cliente</div><div class="empty-text">Adicione seu primeiro cliente.</div><button class="btn btn-primary" id="emptyAddBtn">+ Novo Cliente</button></div>`;
    document.getElementById('emptyAddBtn')?.addEventListener('click', openAddClient);
    return;
  }
  const {startDate} = getWeekBounds();
  const todayStr = fmt(new Date());
  grid.innerHTML = allClients.map(c=>{
    const initial = c.name.charAt(0).toUpperCase();
    const since = new Date(c.created_at);
    const sinceStr = !isNaN(since) ? `Desde ${since.getDate()}/${since.getMonth()+1}/${since.getFullYear()}` : '';
    const dots = Array.from({length:7},(_,i)=>{
      const d=new Date(startDate); d.setDate(startDate.getDate()+i);
      const ds=fmt(d);
      const dayPosts=(weekPosts[ds]||[]).filter(p=>String(p.client_id)===String(c.id));
      const isHoliday = !!allHolidays[ds];
      const isToday = ds===todayStr;
      const isMarked = dayPosts.some(p=>p.status==='published');
      const cls = isMarked ? 'marked' : isHoliday ? 'is-holiday' : '';
      return `<div class="week-dot-col">
        <span class="wd-label">${DS[d.getDay()]}</span>
        <div class="wd-dot ${cls} ${isToday?'today':''}" data-client="${c.id}" data-date="${ds}" title="${isHoliday?allHolidays[ds]:DS[d.getDay()]}">
          ${isMarked ? '✓' : isHoliday ? '🎉' : ''}
        </div>
      </div>`;
    }).join('');
    const hasSync = !!c.sync_url;
    const syncBadge = hasSync ? `<div class="client-sync-badge" style="font-size: 11px; margin-top: 4px; color: var(--text-3); font-weight: 500;">🔗 ${c.sync_url.toLowerCase().includes('idib') ? 'IDIB' : 'IDECAN'}</div>` : '';
    
    const avatarHtml = c.photo
      ? `<img class="client-photo" src="${c.photo}" alt="${c.name}"/>`
      : `<div class="client-avatar" style="background:${c.color}">${initial}</div>`;
    const nameHtml = c.instagram
      ? `<a class="client-ig-link" href="${igUrl(c.instagram)}" target="_blank" title="Abrir Instagram">${c.name} <span class="ig-arrow">↗</span></a>`
      : `<span>${c.name}</span>`;
    const isFixed = (c.name === 'IDIB' || c.name === 'IDECAN');
    const deleteBtnHtml = isFixed ? '' : `<button class="card-action-btn danger" data-del="${c.id}" title="Remover">🗑️</button>`;

    return `<div class="client-card" id="card-${c.id}">
      <div class="client-card-header">
        <div class="client-card-left">
          ${avatarHtml}
          <div class="client-info">
            <div class="client-name">${nameHtml}</div>
            <div class="client-since">${sinceStr}</div>
            ${syncBadge}
          </div>
        </div>
        <div class="client-card-actions">
          ${hasSync ? `<button class="card-action-btn sync-btn" data-sync="${c.id}" title="Sincronizar Datas">🔄</button>` : ''}
          <button class="card-action-btn" data-edit="${c.id}" title="Editar">✏️</button>
          ${deleteBtnHtml}
        </div>
      </div>
      <div class="client-card-body">
        <div class="week-label">Esta semana — clique no dia para marcar</div>
        <div class="week-dots-row">${dots}</div>
      </div>
      <div class="client-card-footer">
        <a href="cliente.php?id=${c.id}" class="btn btn-primary">📆 Abrir Calendário</a>
      </div>
    </div>`;
  }).join('');

  // Dot toggle: click = mark done / click again = unmark (no modal, no title)
  grid.querySelectorAll('.wd-dot').forEach(el=>{
    el.addEventListener('click', async e=>{
      e.stopPropagation();
      const clientId = el.dataset.client, ds = el.dataset.date;
      if(allHolidays[ds]) return; // skip holiday cells
      const dayPosts = (weekPosts[ds]||[]).filter(p=>String(p.client_id)===String(clientId));
      const isMarked = dayPosts.some(p=>p.status==='published');
      // Delete all posts for this client+day
      await Promise.all(dayPosts.map(p=>api(`api/posts.php?id=${p.id}`,{method:'DELETE'})));
      if(!isMarked){
        await api('api/posts.php',{method:'POST',body:JSON.stringify({client_id:clientId,date:ds,title:'Feito',status:'published'})});
        toast('✓ Marcado!');
      } else {
        toast('↩ Desmarcado');
      }
      loadAll();
    });
  });
  grid.querySelectorAll('[data-sync]').forEach(el=>{
    el.addEventListener('click', async e=>{
      e.stopPropagation();
      el.classList.add('spinning');
      el.disabled = true;
      try {
        const res = await api(`api/sync.php?client_id=${el.dataset.sync}`);
        if(res.success) {
          toast(res.message);
        } else {
          toast(`⚠️ ${res.error || 'Erro na sincronização'}`);
        }
      } catch (err) {
        toast('⚠️ Erro ao conectar na API de sincronização');
      } finally {
        el.classList.remove('spinning');
        el.disabled = false;
        loadAll();
      }
    });
  });
  grid.querySelectorAll('[data-edit]').forEach(el=>el.addEventListener('click',()=>openEditClient(el.dataset.edit)));
  grid.querySelectorAll('[data-del]').forEach(el=>el.addEventListener('click',()=>deleteClient(el.dataset.del)));
}

// ── Mark Modal ────────────────────────────
function openMarkModal(clientId, date){
  markClientId = clientId;
  markDate = date || fmt(new Date());
  markStatus = 'published';
  const c = allClients.find(x=>String(x.id)===String(clientId));
  document.getElementById('markTitle').textContent = date ? formatDateLabel(date) : 'Marcar Postagem';
  document.getElementById('markSub').textContent = c?.name ?? '';
  document.getElementById('markPostTitle').value = '';

  // Existing posts
  const posts = (weekPosts[markDate]||[]).filter(p=>String(p.client_id)===String(clientId));
  const area = document.getElementById('existingPostsArea');
  if(posts.length){
    area.innerHTML = `<div class="section-label" style="margin-top:12px">Já marcados neste dia</div>`+
      posts.map(p=>`<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);font-size:13px">
        <span class="pill pill-published" style="flex-shrink:0">✓</span>
        <span style="flex:1">${p.title||'(sem título)'}</span>
        <button style="background:none;border:none;color:var(--text-3);cursor:pointer;font-size:13px" data-delpost="${p.id}">✕</button>
      </div>`).join('');
    area.querySelectorAll('[data-delpost]').forEach(btn=>{
      btn.addEventListener('click',()=>deletePost(btn.dataset.delpost));
    });
  } else { area.innerHTML=''; }

  openModal('modalMark');
  setTimeout(()=>document.getElementById('markPostTitle').focus(),100);
}

function formatDateLabel(ds){
  const d=new Date(ds+'T12:00:00');
  return `${DS[d.getDay()]}, ${d.getDate()} de ${ML[d.getMonth()]}`;
}

async function saveMark(){
  const title = document.getElementById('markPostTitle').value.trim();
  if(!title){ toast('⚠️ Digite o título do post'); return; }
  await api('api/posts.php',{method:'POST',body:JSON.stringify({client_id:markClientId,date:markDate,title,status:markStatus})});
  toast('✅ Marcado com sucesso!');
  closeModal('modalMark');
  loadAll();
}

async function deletePost(id){
  await api(`api/posts.php?id=${id}`,{method:'DELETE'});
  toast('🗑️ Post removido');
  loadAll();
  closeModal('modalMark');
}

// ── Holiday Widget ────────────────────────
function renderHolidayWidget(){
  miniCalYear  = miniCalYear  || new Date().getFullYear();
  miniCalMonth = miniCalMonth !== undefined ? miniCalMonth : new Date().getMonth();
  const widget = document.getElementById('holidayWidget');
  widget.innerHTML = buildMiniCal() + buildHolidayList();
  widget.querySelector('#btnMiniPrev').addEventListener('click',()=>{ if(miniCalMonth===0){miniCalMonth=11;miniCalYear--;}else miniCalMonth--; renderHolidayWidget(); });
  widget.querySelector('#btnMiniNext').addEventListener('click',()=>{ if(miniCalMonth===11){miniCalMonth=0;miniCalYear++;}else miniCalMonth++; renderHolidayWidget(); });
}

function buildMiniCal(){
  const todayStr = fmt(new Date());
  const first = new Date(miniCalYear, miniCalMonth, 1);
  const last  = new Date(miniCalYear, miniCalMonth+1, 0);
  const startDow = first.getDay();

  const cells = [];
  for(let i=0;i<startDow;i++) cells.push({day:new Date(miniCalYear,miniCalMonth,1-(startDow-i)).getDate(),other:true,ds:''});
  for(let d=1;d<=last.getDate();d++){
    const ds=`${miniCalYear}-${String(miniCalMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    cells.push({day:d,other:false,ds,holiday:!!allHolidays[ds],deadline:!!allDeadlines[ds],today:ds===todayStr});
  }
  while(cells.length%7!==0) cells.push({day:cells.length-startDow-last.getDate()+1,other:true,ds:''});

  const cellsHtml = cells.map(c=>{
    if (c.other) return `<div class="mcc other">${c.day}</div>`;

    const classes = [];
    if (c.today) classes.push('today');
    if (c.holiday) classes.push('is-holiday');
    if (c.deadline) classes.push('is-deadline');

    let titleText = '';
    if (c.holiday) titleText = allHolidays[c.ds];
    if (c.deadline && allDeadlines[c.ds]) {
      const dTitles = allDeadlines[c.ds].map(t=>t.replace(/\[.*?\]\s*/, '')).join(', ');
      titleText = titleText ? `${titleText} | ${dTitles}` : dTitles;
    }
    if (!titleText) titleText = DS[new Date(c.ds+'T12:00:00').getDay()];

    return `<div class="mcc ${classes.join(' ')}" title="${titleText}">${c.day}</div>`;
  }).join('');
  const wds = ['D','S','T','Q','Q','S','S'].map(d=>`<div class="mini-cal-wd">${d}</div>`).join('');

  return `<div class="mini-cal">
    <div class="mini-cal-header">
      <button class="mini-cal-nav" id="btnMiniPrev">‹</button>
      <span class="mini-cal-month">${ML[miniCalMonth].slice(0,3).toUpperCase()} ${miniCalYear}</span>
      <button class="mini-cal-nav" id="btnMiniNext">›</button>
    </div>
    <div class="mini-cal-weekdays">${wds}</div>
    <div class="mini-cal-grid">${cellsHtml}</div>
  </div>`;
}

function buildHolidayList(){
  const todayStr = fmt(new Date());
  const upcoming = Object.entries(allHolidays)
    .filter(([d])=>d>=todayStr)
    .sort(([a],[b])=>a.localeCompare(b))
    .slice(0,8);
  if(!upcoming.length) return '';
  const items = upcoming.map(([ds,name])=>{
    const d=new Date(ds+'T12:00:00');
    const isNext = ds===upcoming[0][0];
    return `<div class="hw-item ${isNext?'upcoming':''}">
      <span class="hw-item-date">${d.getDate()} ${ML[d.getMonth()].slice(0,3)}</span>
      <span class="hw-item-name">🎉 ${name}</span>
    </div>`;
  }).join('');
  return `<div class="hw-list"><div class="hw-title">Próximos Feriados</div>${items}</div>`;
}

// ── Client CRUD ───────────────────────────
function updatePhotoPreview(){
  const img=document.getElementById('photoPreviewImg');
  const hint=document.getElementById('purHint');
  if(selectedPhoto){ img.src=selectedPhoto; img.style.display='block'; hint.style.display='none'; }
  else { img.style.display='none'; hint.style.display=''; }
}
function openAddClient(){
  editingClientId=null; selectedPhoto='';
  document.getElementById('clientModalTitle').textContent='Novo Cliente';
  document.getElementById('clientNameInput').value='';
  document.getElementById('igInput').value='';
  document.getElementById('clientSyncUrlInput').value='';
  selectedColor='#6366f1'; syncSwatches(); updatePhotoPreview();
  openModal('modalClient');
  setTimeout(()=>document.getElementById('clientNameInput').focus(),100);
}
function openEditClient(id){
  const c=allClients.find(x=>String(x.id)===String(id));
  editingClientId=id; selectedPhoto=c.photo||'';
  document.getElementById('clientModalTitle').textContent='Editar Cliente';
  document.getElementById('clientNameInput').value=c.name;
  document.getElementById('igInput').value=c.instagram || '';
  document.getElementById('clientSyncUrlInput').value=c.sync_url || '';
  selectedColor=c.color; syncSwatches(); updatePhotoPreview();
  openModal('modalClient');
}
function syncSwatches(){
  document.querySelectorAll('.color-swatch').forEach(el=>el.classList.toggle('active',el.dataset.color===selectedColor));
}
async function saveClient(){
  const name=document.getElementById('clientNameInput').value.trim();
  const instagram=document.getElementById('igInput').value.trim().replace(/^@/,'');
  const sync_url=document.getElementById('clientSyncUrlInput').value.trim();
  if(!name){ toast('⚠️ Digite o nome'); return; }
  try {
    if(editingClientId){
      await api(`api/clients.php?id=${editingClientId}`,{method:'PUT',body:JSON.stringify({name,color:selectedColor,sync_url,instagram,photo:selectedPhoto})});
      toast('✅ Atualizado!');
    } else {
      await api('api/clients.php',{method:'POST',body:JSON.stringify({name,color:selectedColor,sync_url,instagram,photo:selectedPhoto})});
      toast('✅ Cliente adicionado!');
    }
    closeModal('modalClient'); loadAll();
  } catch (err) {
    toast('⚠️ ' + err.message);
  }
}
async function deleteClient(id){
  const c=allClients.find(x=>String(x.id)===String(id));
  if(!confirm(`Remover "${c?.name}"?`)) return;
  try {
    await api(`api/clients.php?id=${id}`,{method:'DELETE'});
    toast('🗑️ Removido'); loadAll();
  } catch (err) {
    toast('⚠️ Erro: ' + err.message);
  }
}

// ── Events ────────────────────────────────
document.getElementById('btnNewClient').addEventListener('click', openAddClient);
document.getElementById('btnCloseClientModal').addEventListener('click', ()=>closeModal('modalClient'));
document.getElementById('btnCancelClient').addEventListener('click', ()=>closeModal('modalClient'));
document.getElementById('btnSaveClient').addEventListener('click', saveClient);
document.getElementById('clientNameInput').addEventListener('keydown', e=>{if(e.key==='Enter')saveClient();});

// Photo upload
const photoInput = document.getElementById('photoInput');
document.getElementById('photoRing').addEventListener('click', ()=>photoInput.click());
document.getElementById('btnPickPhoto').addEventListener('click', ()=>photoInput.click());
document.getElementById('btnRemovePhoto').addEventListener('click', ()=>{selectedPhoto='';updatePhotoPreview();});
photoInput.addEventListener('change', ()=>{
  const file = photoInput.files[0]; if(!file) return;
  const reader = new FileReader();
  reader.onload = e=>{selectedPhoto=e.target.result;updatePhotoPreview();};
  reader.readAsDataURL(file);
});

document.getElementById('btnCloseMark').addEventListener('click', ()=>closeModal('modalMark'));
document.getElementById('btnCancelMark').addEventListener('click', ()=>closeModal('modalMark'));
document.getElementById('btnSaveMark').addEventListener('click', saveMark);



document.querySelectorAll('.color-swatch').forEach(el=>{
  el.addEventListener('click',()=>{ selectedColor=el.dataset.color; syncSwatches(); });
});
document.querySelectorAll('.modal-overlay').forEach(o=>{
  o.addEventListener('click',e=>{ if(e.target===o) o.classList.remove('open'); });
});

loadAll();
