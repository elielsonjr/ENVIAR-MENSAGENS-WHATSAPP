// ══════════════════════════════════════════
//  client.js — Month Calendar View
// ══════════════════════════════════════════

const DAYS_LONG  = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
const MONTHS_L   = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

const clientId   = new URLSearchParams(location.search).get('id');
let client       = null;
let calYear      = new Date().getFullYear();
let calMonth     = new Date().getMonth();
let monthPosts   = {};   // {dateStr:[post,...]}
let monthNotes   = {};   // {dateStr:text}
let holidays     = {};   // {dateStr:name}
let openDayStr   = null;

function fmt(d){ const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),dd=String(d.getDate()).padStart(2,'0'); return `${y}-${m}-${dd}`; }
function api(p,o={}){
  let url = p;
  if (!o.method || o.method.toUpperCase() === 'GET') {
    const separator = p.includes('?') ? '&' : '?';
    url = `${p}${separator}_t=${Date.now()}`;
  }
  return fetch(url,{headers:{'Content-Type':'application/json'},...o})
    .then(async r=>{
      const text = await r.text();
      let json;
      try {
        json = JSON.parse(text);
      } catch (err) {
        throw new Error(text.slice(0, 150) || `Erro HTTP ${r.status}`);
      }
      if (!r.ok || (json && json.error)) {
        throw new Error(json?.error || `Erro HTTP ${r.status}`);
      }
      return json;
    });
}
function toast(m){ const el=document.getElementById('toast'); el.textContent=m; el.classList.add('show'); clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),2500); }
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
function esc(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// ── Init ──────────────────────────────────
async function init(){
  if(!clientId){ location.href='index.php'; return; }
  try {
    const clients = await api('api/clients.php');
    client = clients.find(c=>String(c.id)===clientId);
    if(!client){ location.href='index.php'; return; }
    document.getElementById('clientName').textContent = client.name;
    document.getElementById('clientDot').style.background = client.color;
    document.title = `${client.name} — PostManager`;

    const yr = new Date().getFullYear();
    const [h1,h2] = await Promise.all([
      api(`api/holidays.php?year=${yr}`),
      api(`api/holidays.php?year=${yr+1}`),
    ]);
    [...h1,...h2].forEach(h=>{ holidays[h.date]=h.name; });
    await loadMonth();
  } catch (err) {
    toast('⚠️ Erro ao inicializar: ' + err.message);
  }
}

async function loadMonth(){
  const start = `${calYear}-${String(calMonth+1).padStart(2,'0')}-01`;
  const last  = new Date(calYear,calMonth+1,0).getDate();
  const end   = `${calYear}-${String(calMonth+1).padStart(2,'0')}-${String(last).padStart(2,'0')}`;

  try {
    const [posts,notes] = await Promise.all([
      api(`api/posts.php?client_id=${clientId}&week_start=${start}&week_end=${end}`),
      api(`api/notes.php?client_id=${clientId}&week_start=${start}&week_end=${end}`),
    ]);

    monthPosts = {};
    posts.forEach(p=>{ if(!monthPosts[p.date]) monthPosts[p.date]=[]; monthPosts[p.date].push(p); });
    monthNotes = {};
    notes.forEach(n=>{ monthNotes[n.date]=n.content; });

    renderMonth();
  } catch (err) {
    toast('⚠️ Erro ao carregar mês: ' + err.message);
  }
}

// ── Render ────────────────────────────────
function renderMonth(){
  document.getElementById('monthTitle').textContent = `${MONTHS_L[calMonth]} ${calYear}`;

  // Pills
  const all = Object.values(monthPosts).flat();
  const pu = all.length;
  document.getElementById('mpPublished').textContent = `${pu} postagem${pu!==1?'ns':'m'} concluída${pu!==1?'s':''}`;

  const todayStr   = fmt(new Date());
  const first      = new Date(calYear, calMonth, 1);
  const lastDay    = new Date(calYear, calMonth+1, 0);
  const startDow   = first.getDay();

  const cells = [];
  for(let i=0;i<startDow;i++){
    cells.push({date:new Date(calYear,calMonth,1-(startDow-i)),other:true});
  }
  for(let d=1;d<=lastDay.getDate();d++){
    cells.push({date:new Date(calYear,calMonth,d),other:false});
  }
  while(cells.length%7!==0){
    cells.push({date:new Date(calYear,calMonth+1,cells.length-startDow-lastDay.getDate()+1),other:true});
  }

  const body = document.getElementById('calBody');
  body.innerHTML = cells.map(({date,other})=>{
    const ds      = fmt(date);
    const holiday = holidays[ds];
    const posts   = monthPosts[ds] || [];
    const note    = monthNotes[ds] || '';
    const isToday = ds === todayStr;

    const max  = 3;
    const vis  = posts.slice(0,max);
    const more = posts.length - max;

    const chips = [
      holiday ? `<div class="mc-holiday">🎉 ${holiday.length>16?holiday.slice(0,16)+'…':holiday}</div>` : '',
      ...vis.map(p=>`<div class="mc-chip ${p.status}">${esc(p.title)||'(post)'}</div>`),
      more>0 ? `<div class="mc-more">+${more} mais</div>` : '',
    ].filter(Boolean).join('');

    return `<div class="month-cell ${other?'other-month':''} ${isToday?'today':''} ${holiday&&!other?'is-holiday':''}"
      ${other?'':` data-ds="${ds}"`}>
      <div class="mc-day">${date.getDate()}</div>
      ${chips}
      ${note&&!other?'<div class="mc-note-dot"></div>':''}
    </div>`;
  }).join('');

  // Click events (only non-other cells)
  body.querySelectorAll('.month-cell:not(.other-month)').forEach(cell=>{
    cell.addEventListener('click', ()=>openDayModal(cell.dataset.ds));
  });
}

// ── Day Modal ─────────────────────────────
function openDayModal(ds){
  openDayStr = ds;
  const d = new Date(ds+'T12:00:00');
  const holiday = holidays[ds];
  document.getElementById('dayModalTitle').textContent = `${DAYS_LONG[d.getDay()]}, ${d.getDate()} de ${MONTHS_L[d.getMonth()]}`;
  document.getElementById('dayModalSub').textContent   = client?.name ?? '';

  const alert = document.getElementById('dayHolidayAlert');
  if(holiday){ alert.style.display=''; alert.textContent=`🎉 ${holiday}`; }
  else { alert.style.display='none'; }

  document.getElementById('dayNote').value = monthNotes[ds] || '';
  renderModalPosts(ds);
  openModal('modalDay');
}

function renderModalPosts(ds){
  const posts = monthPosts[ds] || [];
  const list  = document.getElementById('dayPostsList');
  list.innerHTML = posts.map((p,i)=>{
    return `<div class="modal-post-row" data-idx="${i}">
      <input class="modal-post-title" value="${esc(p.title)}" placeholder="Título do post…" data-idx="${i}"/>
      <button class="modal-post-del" data-idx="${i}">✕</button>
    </div>`;
  }).join('');

  // Events
  list.querySelectorAll('.modal-post-title').forEach(inp=>{
    inp.addEventListener('change',()=>{
      const i=parseInt(inp.dataset.idx);
      if(monthPosts[openDayStr]?.[i]) monthPosts[openDayStr][i].title=inp.value;
    });
  });
  list.querySelectorAll('.modal-post-del').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const i=parseInt(btn.dataset.idx);
      monthPosts[openDayStr] = (monthPosts[openDayStr]||[]).filter((_,idx)=>idx!==i);
      renderModalPosts(openDayStr);
    });
  });
}

function addModalPost(){
  if(!monthPosts[openDayStr]) monthPosts[openDayStr]=[];
  monthPosts[openDayStr].push({id:null,title:'',status:'published'});
  renderModalPosts(openDayStr);
  document.querySelector('#dayPostsList .modal-post-row:last-child .modal-post-title')?.focus();
}

async function saveDayModal(){
  const posts  = monthPosts[openDayStr] || [];
  const note   = document.getElementById('dayNote').value.trim();
  const ds     = openDayStr;

  // Collect current titles from inputs
  document.querySelectorAll('#dayPostsList .modal-post-title').forEach((inp,i)=>{
    if(posts[i]) posts[i].title = inp.value.trim();
  });

  try {
    // Save posts: delete old ones for this day, then re-create
    // Get server posts for this day
    const serverPosts = await api(`api/posts.php?client_id=${clientId}&date=${ds}`);
    // Delete all
    await Promise.all(serverPosts.map(p=>api(`api/posts.php?id=${p.id}`,{method:'DELETE'})));
    // Create new ones
    await Promise.all(posts.filter(p=>p.title).map(p=>api('api/posts.php',{method:'POST',body:JSON.stringify({client_id:clientId,date:ds,title:p.title,status:p.status})})));
    // Save note
    await api('api/notes.php',{method:'POST',body:JSON.stringify({client_id:clientId,date:ds,content:note})});

    toast('💾 Salvo!');
    closeModal('modalDay');
    await loadMonth();
  } catch (err) {
    toast('⚠️ Erro ao salvar: ' + err.message);
  }
}

// ── Nav ───────────────────────────────────
document.getElementById('btnPrevMonth').addEventListener('click',()=>{ if(calMonth===0){calMonth=11;calYear--;}else calMonth--; loadMonth(); });
document.getElementById('btnNextMonth').addEventListener('click',()=>{ if(calMonth===11){calMonth=0;calYear++;}else calMonth++; loadMonth(); });
document.getElementById('btnThisMonth').addEventListener('click',()=>{ calYear=new Date().getFullYear(); calMonth=new Date().getMonth(); loadMonth(); });
document.getElementById('btnAddToday').addEventListener('click',()=>openDayModal(fmt(new Date())));
document.getElementById('btnAddPost').addEventListener('click', addModalPost);
document.getElementById('btnSaveDay').addEventListener('click', saveDayModal);
document.getElementById('btnCloseDay').addEventListener('click',()=>closeModal('modalDay'));
document.getElementById('btnCancelDay').addEventListener('click',()=>closeModal('modalDay'));
document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{ if(e.target===o) o.classList.remove('open'); }));

init();
