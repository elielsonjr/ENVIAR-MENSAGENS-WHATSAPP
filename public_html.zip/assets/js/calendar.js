// ══════════════════════════════════════════
//  Calendar Modal — calendar.js
//  Shared by client page (month view)
// ══════════════════════════════════════════

const CAL_DAYS_SHORT  = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const CAL_MONTHS_LONG = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                          'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

let calYear  = new Date().getFullYear();
let calMonth = new Date().getMonth();

// calAllPosts: { dateStr: [post,...] }
// calHolidays: { dateStr: name }
// These come from the host page's scope

async function openCalendarModal() {
  calYear  = new Date().getFullYear();
  calMonth = new Date().getMonth();
  await loadCalMonth();
  openModal('modalCalendar');
}

async function loadCalMonth() {
  const start = `${calYear}-${String(calMonth+1).padStart(2,'0')}-01`;
  const last  = new Date(calYear, calMonth+1, 0).getDate();
  const end   = `${calYear}-${String(calMonth+1).padStart(2,'0')}-${String(last).padStart(2,'0')}`;

  const [posts, hols] = await Promise.all([
    fetch(`api/posts.php?client_id=${clientId}&week_start=${start}&week_end=${end}`)
      .then(r=>r.json()),
    fetch(`api/holidays.php?year=${calYear}`)
      .then(r=>r.json()),
  ]);

  const calPosts = {};
  posts.forEach(p => {
    if (!calPosts[p.date]) calPosts[p.date] = [];
    calPosts[p.date].push(p);
  });

  const calHolidays = {};
  hols.forEach(h => { calHolidays[h.date] = h.name; });

  renderCalGrid(calPosts, calHolidays);
}

function renderCalGrid(calPosts, calHolidays) {
  document.getElementById('calMonthTitle').textContent =
    `${CAL_MONTHS_LONG[calMonth]} ${calYear}`;

  const firstDay = new Date(calYear, calMonth, 1);
  const lastDay  = new Date(calYear, calMonth+1, 0);
  const startDow = firstDay.getDay();
  const todayStr = fmt(new Date());

  const cells = [];
  for (let i = 0; i < startDow; i++) {
    cells.push({ date: new Date(calYear, calMonth, 1-(startDow-i)), other: true });
  }
  for (let d = 1; d <= lastDay.getDate(); d++) {
    cells.push({ date: new Date(calYear, calMonth, d), other: false });
  }
  while (cells.length % 7 !== 0) {
    cells.push({ date: new Date(calYear, calMonth+1, cells.length-startDow-lastDay.getDate()+1), other: true });
  }

  const body = document.getElementById('calGridBody');
  body.innerHTML = cells.map(({date, other}) => {
    const ds = fmt(date);
    const holiday = calHolidays[ds];
    const posts   = calPosts[ds] || [];
    const isToday = ds === todayStr;
    const max = 2;
    const visible = posts.slice(0, max);
    const more    = posts.length - max;

    const chips = [
      holiday ? `<div class="cal-holiday-chip">🎉 ${holiday.length>14?holiday.slice(0,14)+'…':holiday}</div>` : '',
      ...visible.map(p => `<div class="cal-post-chip ${p.status}">${p.title || '(sem título)'}</div>`),
      more > 0 ? `<div class="cal-more">+${more}</div>` : '',
    ].join('');

    return `<div class="cal-cell ${other?'other':''} ${isToday?'today':''} ${holiday?'has-holiday':''}"
               onclick="${other?'':` navigateWeekTo('${ds}') `}">
      <div class="cal-day-num">${date.getDate()}</div>
      ${chips}
    </div>`;
  }).join('');
}

function fmt(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth()+1).padStart(2,'0');
  const d = String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}

function calPrevMonth() {
  if (calMonth === 0) { calMonth = 11; calYear--; }
  else calMonth--;
  loadCalMonth();
}

function calNextMonth() {
  if (calMonth === 11) { calMonth = 0; calYear++; }
  else calMonth++;
  loadCalMonth();
}

// Navigate to the week containing a date (from calendar click)
function navigateWeekTo(ds) {
  const target = new Date(ds + 'T12:00:00');
  const today  = new Date();
  today.setHours(12,0,0,0);

  const todayDow  = today.getDay();
  const todayMon  = new Date(today); todayMon.setDate(today.getDate() - todayDow);
  const targetDow = target.getDay();
  const targetMon = new Date(target); targetMon.setDate(target.getDate() - targetDow);

  const diff = Math.round((targetMon - todayMon) / (7 * 86400000));
  weekOffset = diff;

  closeModal('modalCalendar');
  loadWeek();
}
