<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $clientId = isset($_GET['client_id']) ? (int)$_GET['client_id'] : null;
    if (!$clientId) {
        jsonResponse(['error' => 'client_id é obrigatório'], 400);
    }

    $db = getDB();

    // 1. Busca o cliente e valida o sync_url
    $stmt = $db->prepare('SELECT * FROM clients WHERE id = ?');
    $stmt->execute([$clientId]);
    $client = $stmt->fetch();

    if (!$client) {
        jsonResponse(['error' => 'Cliente não encontrado'], 404);
    }

    $syncUrl = $client['sync_url'] ?? '';
    if (empty($syncUrl)) {
        jsonResponse(['error' => 'Este cliente não possui uma URL de sincronização configurada.'], 400);
    }

    // 2. Função auxiliar para cURL
    if (!function_exists('fetchUrl')) {
        function fetchUrl(string $url): string|false {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode !== 200 || $response === false) {
                return false;
            }
            return $response;
        }
    }

    // 3. Determina o tipo de crawler baseado na URL
    $isIdib = (stripos($syncUrl, 'idib.org.br') !== false);
    $isIdecan = (stripos($syncUrl, 'idecan.org.br') !== false || stripos($syncUrl, 'idecan.selecao.net.br') !== false);

    if (!$isIdib && !$isIdecan) {
        jsonResponse(['error' => 'URL de sincronização inválida. Apenas IDIB ou IDECAN são suportados.'], 400);
    }

    // 4. Limpa posts de sincronização anteriores para este cliente
    $db->prepare("DELETE FROM posts WHERE client_id = ? AND (title LIKE '[IDIB]%' OR title LIKE '[IDECAN]%')")->execute([$clientId]);

    $inserted = 0;

    if ($isIdib) {
        // IDIB: A lista de concursos fica na subpágina de login de candidato
        $targetUrl = 'https://concurso.idib.org.br/SITE/CandidatoLogin.aspx?AcessoInicial=1';
        $html = fetchUrl($targetUrl);
        
        if ($html === false) {
            jsonResponse(['error' => 'Falha ao conectar com o servidor da IDIB.'], 500);
        }
        
        // Converter de ISO-8859-1 para UTF-8 caso necessário
        $html = mb_convert_encoding($html, 'UTF-8', 'ISO-8859-1, UTF-8');
        
        // Regex para buscar o link do concurso, o título e a data limite de inscrições
        $pattern = '/<a[^>]+href="([^"]*Concurso\.aspx\?ID=(\d+))"[^>]*>([^<]+)<\/a>\s*<br\s*\/?>\s*Inscrições até:\s*(\d{2}\/\d{2}\/\d{4})/i';
        
        if (preg_match_all($pattern, $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $title = html_entity_decode(strip_tags(trim($match[3])), ENT_QUOTES, 'UTF-8');
                $title = preg_replace('/\s+/', ' ', $title);
                $dateStr = $match[4];
                
                // Converter data para YYYY-MM-DD
                $parts = explode('/', $dateStr);
                if (count($parts) === 3) {
                    $formattedDate = $parts[2] . '-' . $parts[1] . '-' . $parts[0];
                    
                    $postTitle = "[IDIB] Inscrições até: " . $title;
                    
                    $insertStmt = $db->prepare('INSERT INTO posts (client_id, date, title, status) VALUES (?, ?, ?, ?)');
                    $insertStmt->execute([$clientId, $formattedDate, $postTitle, 'planned']);
                    $inserted++;
                }
            }
        }
    } else if ($isIdecan) {
        // IDECAN: Buscamos da plataforma selecao.net.br que é livre de Cloudflare e tem as datas
        $targetUrl = 'https://idecan.selecao.net.br/';
        $html = fetchUrl($targetUrl);
        
        if ($html === false) {
            jsonResponse(['error' => 'Falha ao conectar com o servidor da IDECAN.'], 500);
        }
        
        // Converter de ISO-8859-1 para UTF-8 caso necessário
        $html = mb_convert_encoding($html, 'UTF-8', 'ISO-8859-1, UTF-8');
        
        // Dividir itens por li class="item"
        $items = explode('<li class="item">', $html);
        array_shift($items); // descarta texto inicial
        
        foreach ($items as $item) {
            // Encontra título e link do concurso
            if (preg_match('#<h3><a\s+href="([^"]+)"[^>]*>(.+?)</a></h3>#is', $item, $titleMatches)) {
                $title = html_entity_decode(strip_tags(trim($titleMatches[2])), ENT_QUOTES, 'UTF-8');
                $title = preg_replace('/\s+/', ' ', $title);
                
                // Encontra período de inscrição
                if (preg_match('#class="inscricoes-info-mobile-only"[^>]*>.*?de\s*<b>(\d{2}/\d{2}/\d{4})</b>\s*a\s*<b>(\d{2}/\d{2}/\d{4})</b>#is', $item, $dateMatches)) {
                    $startDateStr = $dateMatches[1];
                    $endDateStr = $dateMatches[2];
                    
                    // Converter data de início
                    $startParts = explode('/', $startDateStr);
                    $startDate = $startParts[2] . '-' . $startParts[1] . '-' . $startParts[0];
                    
                    // Converter data de fim
                    $endParts = explode('/', $endDateStr);
                    $endDate = $endParts[2] . '-' . $endParts[1] . '-' . $endParts[0];
                    
                    // Inserir postagem de início
                    $startTitle = "[IDECAN] Início Inscrições: " . $title;
                    $insertStmt = $db->prepare('INSERT INTO posts (client_id, date, title, status) VALUES (?, ?, ?, ?)');
                    $insertStmt->execute([$clientId, $startDate, $startTitle, 'planned']);
                    
                    // Inserir postagem de fim
                    $endTitle = "[IDECAN] Fim Inscrições: " . $title;
                    $insertStmt = $db->prepare('INSERT INTO posts (client_id, date, title, status) VALUES (?, ?, ?, ?)');
                    $insertStmt->execute([$clientId, $endDate, $endTitle, 'planned']);
                    
                    $inserted += 2;
                }
            }
        }
    }

    jsonResponse([
        'success' => true,
        'message' => "Sincronização concluída com sucesso! {$inserted} datas adicionadas/atualizadas no calendário.",
        'inserted_count' => $inserted
    ]);
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
} catch (Throwable $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}
