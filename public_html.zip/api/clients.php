<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $method = $_SERVER['REQUEST_METHOD'];
    $db     = getDB();
    $id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

    switch ($method) {

        case 'GET':
            ensureFixedClientsExist($db);
            $stmt = $db->query("SELECT * FROM clients ORDER BY CASE WHEN name = 'IDIB' THEN 1 WHEN name = 'IDECAN' THEN 2 ELSE 3 END ASC, name ASC");
            jsonResponse($stmt->fetchAll());
            break;

        case 'POST':
            $body  = getRequestBody();
            $name  = sanitize($body['name'] ?? '');
            $color = preg_match('/^#[0-9a-fA-F]{6}$/', $body['color'] ?? '') ? $body['color'] : '#6366f1';
            $syncUrl = isset($body['sync_url']) ? sanitize(trim($body['sync_url'])) : null;
            if ($syncUrl === '') $syncUrl = null;
            $instagram = isset($body['instagram']) ? sanitize(trim($body['instagram'])) : null;
            if ($instagram === '') $instagram = null;
            $photo = isset($body['photo']) ? trim($body['photo']) : null;
            if ($photo === '') $photo = null;

            if (!$name) jsonResponse(['error' => 'Nome é obrigatório'], 400);
            $stmt  = $db->prepare('INSERT INTO clients (name, color, sync_url, instagram, photo) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$name, $color, $syncUrl, $instagram, $photo]);
            jsonResponse(['id' => (int)$db->lastInsertId(), 'name' => $name, 'color' => $color, 'sync_url' => $syncUrl, 'instagram' => $instagram, 'photo' => $photo], 201);
            break;

        case 'PUT':
            if (!$id) jsonResponse(['error' => 'ID necessário'], 400);
            $body  = getRequestBody();
            $name  = sanitize($body['name'] ?? '');
            $color = preg_match('/^#[0-9a-fA-F]{6}$/', $body['color'] ?? '') ? $body['color'] : '#6366f1';
            $syncUrl = isset($body['sync_url']) ? sanitize(trim($body['sync_url'])) : null;
            if ($syncUrl === '') $syncUrl = null;
            $instagram = isset($body['instagram']) ? sanitize(trim($body['instagram'])) : null;
            if ($instagram === '') $instagram = null;
            $photo = isset($body['photo']) ? trim($body['photo']) : null;
            if ($photo === '') $photo = null;

            if (!$name) jsonResponse(['error' => 'Nome é obrigatório'], 400);
            $stmt  = $db->prepare('UPDATE clients SET name=?, color=?, sync_url=?, instagram=?, photo=? WHERE id=?');
            $stmt->execute([$name, $color, $syncUrl, $instagram, $photo, $id]);
            jsonResponse(['success' => true]);
            break;

        case 'DELETE':
            if (!$id) jsonResponse(['error' => 'ID necessário'], 400);
            
            // Prevent deleting IDIB and IDECAN
            $stmt = $db->prepare('SELECT name FROM clients WHERE id=?');
            $stmt->execute([$id]);
            $clientName = $stmt->fetchColumn();
            if ($clientName === 'IDIB' || $clientName === 'IDECAN') {
                jsonResponse(['error' => 'Clientes fixados não podem ser removidos.'], 400);
            }

            $db->prepare('DELETE FROM clients WHERE id=?')->execute([$id]);
            jsonResponse(['success' => true]);
            break;

        default:
            jsonResponse(['error' => 'Método não permitido'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
} catch (Throwable $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}

function ensureFixedClientsExist($db) {
    // Check IDIB
    $stmt = $db->prepare('SELECT COUNT(*) FROM clients WHERE name = ?');
    $stmt->execute(['IDIB']);
    if ($stmt->fetchColumn() == 0) {
        $stmt = $db->prepare('INSERT INTO clients (name, color, sync_url) VALUES (?, ?, ?)');
        $stmt->execute(['IDIB', '#3b82f6', 'https://concurso.idib.org.br/']);
    }

    // Check IDECAN
    $stmt = $db->prepare('SELECT COUNT(*) FROM clients WHERE name = ?');
    $stmt->execute(['IDECAN']);
    if ($stmt->fetchColumn() == 0) {
        $stmt = $db->prepare('INSERT INTO clients (name, color, sync_url) VALUES (?, ?, ?)');
        $stmt->execute(['IDECAN', '#ef4444', 'https://concurso.idecan.org.br/']);
    }
}
