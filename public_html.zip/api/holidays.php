<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $method = $_SERVER['REQUEST_METHOD'];
    $db     = getDB();
    $id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

    switch ($method) {

        case 'GET':
            $year = (int)($_GET['year'] ?? date('Y'));
            $nationals = getNationalHolidays($year);

            // Feriados personalizados cadastrados para este ano
            $stmt = $db->prepare("SELECT * FROM holidays WHERE YEAR(date) = ? ORDER BY date ASC");
            $stmt->execute([$year]);
            $custom = $stmt->fetchAll();

            $result = [];
            foreach ($nationals as $date => $name) {
                $result[] = ['date' => $date, 'name' => $name, 'is_national' => true, 'id' => null];
            }
            foreach ($custom as $h) {
                $result[] = [
                    'date'        => $h['date'],
                    'name'        => $h['name'],
                    'is_national' => (bool)$h['is_national'],
                    'id'          => (int)$h['id'],
                ];
            }

            usort($result, fn($a, $b) => strcmp($a['date'], $b['date']));
            jsonResponse($result);

        case 'POST':
            $body = getRequestBody();
            $date = $body['date'] ?? '';
            $name = sanitize($body['name'] ?? '');
            if (!$date || !$name) jsonResponse(['error' => 'date e name são obrigatórios'], 400);

            $stmt = $db->prepare(
                'INSERT INTO holidays (date, name, is_national) VALUES (?, ?, 0)
                 ON DUPLICATE KEY UPDATE name = VALUES(name)'
            );
            $stmt->execute([$date, $name]);
            jsonResponse(['success' => true, 'id' => (int)$db->lastInsertId()], 201);

        case 'DELETE':
            if (!$id) jsonResponse(['error' => 'ID necessário'], 400);
            // Só permite deletar feriados não-nacionais
            $db->prepare('DELETE FROM holidays WHERE id=? AND is_national=0')->execute([$id]);
            jsonResponse(['success' => true]);

        default:
            jsonResponse(['error' => 'Método não permitido'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
} catch (Throwable $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}
