<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $method = $_SERVER['REQUEST_METHOD'];
    $db     = getDB();
    $id     = isset($_GET['id']) ? (int)$_GET['id'] : null;

    switch ($method) {

        case 'GET':
            $clientId  = isset($_GET['client_id']) ? (int)$_GET['client_id'] : null;
            $date      = $_GET['date']       ?? null;
            $weekStart = $_GET['week_start'] ?? null;
            $weekEnd   = $_GET['week_end']   ?? null;
            $deadlines = isset($_GET['deadlines']) ? (int)$_GET['deadlines'] : null;

            if ($deadlines) {
                $stmt = $db->prepare(
                    "SELECT date, title FROM posts 
                     WHERE title LIKE '%Inscrições até:%' OR title LIKE '%Fim Inscrições:%'
                     ORDER BY date ASC"
                );
                $stmt->execute();
                jsonResponse($stmt->fetchAll());
            }

            if ($clientId && $date) {
                // Posts de um cliente em um dia específico
                $stmt = $db->prepare(
                    'SELECT * FROM posts WHERE client_id=? AND date=? ORDER BY sort_order ASC, id ASC'
                );
                $stmt->execute([$clientId, $date]);
                jsonResponse($stmt->fetchAll());
            }

            if ($weekStart && $weekEnd) {
                if ($clientId) {
                    // Posts de um cliente na semana
                    $stmt = $db->prepare(
                        'SELECT * FROM posts WHERE client_id=? AND date BETWEEN ? AND ?
                         ORDER BY date ASC, sort_order ASC, id ASC'
                    );
                    $stmt->execute([$clientId, $weekStart, $weekEnd]);
                } else {
                    // Dashboard: todos os clientes na semana
                    $stmt = $db->prepare(
                        'SELECT p.*, c.name AS client_name, c.color AS client_color
                         FROM posts p JOIN clients c ON p.client_id = c.id
                         WHERE p.date BETWEEN ? AND ?
                         ORDER BY p.client_id, p.date ASC'
                    );
                    $stmt->execute([$weekStart, $weekEnd]);
                }
                jsonResponse($stmt->fetchAll());
            }

            jsonResponse(['error' => 'Parâmetros insuficientes'], 400);

        case 'POST':
            $body     = getRequestBody();
            $clientId = (int)($body['client_id'] ?? 0);
            $date     = $body['date']   ?? '';
            $title    = sanitize($body['title'] ?? '');
            $status   = in_array($body['status'] ?? '', ['planned','scheduled','published'])
                        ? $body['status'] : 'planned';

            if (!$clientId || !$date) jsonResponse(['error' => 'client_id e date são obrigatórios'], 400);

            $stmt = $db->prepare(
                'INSERT INTO posts (client_id, date, title, status) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute([$clientId, $date, $title, $status]);
            $newId = (int)$db->lastInsertId();
            jsonResponse([
                'id'        => $newId,
                'client_id' => $clientId,
                'date'      => $date,
                'title'     => $title,
                'status'    => $status,
            ], 201);

        case 'PUT':
            if (!$id) jsonResponse(['error' => 'ID necessário'], 400);
            $body   = getRequestBody();
            $fields = [];
            $vals   = [];

            if (isset($body['title'])) {
                $fields[] = 'title=?';
                $vals[]   = sanitize($body['title']);
            }
            if (isset($body['status']) && in_array($body['status'], ['planned','scheduled','published'])) {
                $fields[] = 'status=?';
                $vals[]   = $body['status'];
            }
            if (empty($fields)) jsonResponse(['error' => 'Nada para atualizar'], 400);

            $vals[] = $id;
            $db->prepare('UPDATE posts SET ' . implode(',', $fields) . ' WHERE id=?')->execute($vals);
            jsonResponse(['success' => true]);

        case 'DELETE':
            if (!$id) jsonResponse(['error' => 'ID necessário'], 400);
            $db->prepare('DELETE FROM posts WHERE id=?')->execute([$id]);
            jsonResponse(['success' => true]);

        default:
            jsonResponse(['error' => 'Método não permitido'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
} catch (Throwable $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}
