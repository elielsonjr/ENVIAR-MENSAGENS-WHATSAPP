<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $method = $_SERVER['REQUEST_METHOD'];
    $db     = getDB();

    switch ($method) {

        case 'GET':
            $clientId  = isset($_GET['client_id']) ? (int)$_GET['client_id'] : null;
            $date      = $_GET['date']       ?? null;
            $weekStart = $_GET['week_start'] ?? null;
            $weekEnd   = $_GET['week_end']   ?? null;

            if ($clientId && $date) {
                $stmt = $db->prepare('SELECT * FROM notes WHERE client_id=? AND date=?');
                $stmt->execute([$clientId, $date]);
                $row = $stmt->fetch();
                jsonResponse($row ?: ['content' => '']);
            }

            if ($clientId && $weekStart && $weekEnd) {
                $stmt = $db->prepare(
                    'SELECT * FROM notes WHERE client_id=? AND date BETWEEN ? AND ? ORDER BY date ASC'
                );
                $stmt->execute([$clientId, $weekStart, $weekEnd]);
                jsonResponse($stmt->fetchAll());
            }

            jsonResponse([]);

        case 'POST':
            $body     = getRequestBody();
            $clientId = (int)($body['client_id'] ?? 0);
            $date     = $body['date']    ?? '';
            $content  = trim($body['content'] ?? '');

            if (!$clientId || !$date) jsonResponse(['error' => 'client_id e date são obrigatórios'], 400);

            $stmt = $db->prepare(
                'INSERT INTO notes (client_id, date, content) VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE content = VALUES(content)'
            );
            $stmt->execute([$clientId, $date, $content]);
            jsonResponse(['success' => true]);

        default:
            jsonResponse(['error' => 'Método não permitido'], 405);
    }
} catch (Exception $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
} catch (Throwable $e) {
    jsonResponse(['error' => $e->getMessage()], 500);
}
